<?php
echo password_hash('erla123', PASSWORD_DEFAULT);
?>
