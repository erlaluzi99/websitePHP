<?php
include 'includes/db_connect.php';
include 'includes/header.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

$products = $conn->query("SELECT * FROM products ORDER BY id DESC");
?>

<link rel="stylesheet" href="css/admin.css">

<main class="admin-panel">
    <h2>Admin - Product Management</h2>

    <!-- Show messages -->
    <?php if (!empty($_SESSION['product_success'])): ?>
        <p class="success-msg"><?= $_SESSION['product_success']; unset($_SESSION['product_success']); ?></p>
    <?php endif; ?>
    <?php if (!empty($_SESSION['product_error'])): ?>
        <p class="error-msg"><?= $_SESSION['product_error']; unset($_SESSION['product_error']); ?></p>
    <?php endif; ?>

    <div class="admin-container">
        <!-- Add New Product -->
        <section class="admin-form">
            <h3>Add New Product</h3>
            <form action="admin_product_handle.php" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="action" value="add">
                <input type="text" name="name" placeholder="Product Name" required>
                <input type="number" step="0.01" name="price" placeholder="Price" required>
                <select name="category" required>
                    <option value="">-- Select Category --</option>
                    <option value="clothing">Clothing</option>
                    <option value="posters">Posters</option>
                    <option value="plushies">Plushies</option>
                    <option value="figures">Figures</option>
                    <option value="accessories">Accessories</option>
                </select>
                <input type="number" name="stock" placeholder="Stock" required>
                <input type="file" name="image" accept="image/*" required>
                <button type="submit">Add Product</button>
            </form>
        </section>

        <!-- Manage Existing Products -->
        <section class="admin-table">
            <h3>Current Products</h3>
            <table>
                <thead>
                    <tr>
                        <th>ID</th><th>Name</th><th>Price</th><th>Category</th><th>Stock</th><th>Image</th><th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $products->fetch_assoc()): ?>
                        <tr>
                            <form action="admin_product_handle.php" method="POST" enctype="multipart/form-data">
                                <input type="hidden" name="id" value="<?= $row['id'] ?>">
                                <td><?= $row['id'] ?></td>
                                <td><input type="text" name="name" value="<?= htmlspecialchars($row['name']) ?>"></td>
                                <td><input type="number" step="0.01" name="price" value="<?= $row['price'] ?>"></td>
                                <td><input type="text" name="category" value="<?= htmlspecialchars($row['category']) ?>"></td>
                                <td><input type="number" name="stock" value="<?= $row['stock'] ?>"></td>
                                <td>
                                    <img src="<?= htmlspecialchars($row['image']) ?>" class="product-img" width="50"><br>
                                    <input type="file" name="image">
                                </td>
                                <td>
                                    <button type="submit" name="action" value="edit">Update</button>
                                    <button class="action-btn" type="submit" name="action" value="delete">Delete</button>
                                </td>
                            </form>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </section>
    </div>
</main>

<?php include 'includes/footer.php'; ?>
