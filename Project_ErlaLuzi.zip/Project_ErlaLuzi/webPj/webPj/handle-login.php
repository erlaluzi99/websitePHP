<?php
session_start();
include 'includes/db_connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $remember = isset($_POST['remember']);

    $stmt = $conn->prepare("SELECT id, username, password, role FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows === 1) {
        $user = $result->fetch_assoc();

        if (password_verify($password, $user['password'])) {

            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];

            // Remember me logic
            if ($remember) {
                $token = bin2hex(random_bytes(32));
                setcookie('remember_me', $token, time() + (86400 * 30), "/", "", false, true);

                // Store token in DB
                $insert = $conn->prepare("INSERT INTO remember_tokens (user_id, token) VALUES (?, ?)");
                $insert->bind_param("is", $user['id'], $token);
                $insert->execute();
            }

            header("Location: index.php");
            exit;
        }
    }

    $_SESSION['error'] = "Invalid username or password.";
    header("Location: index.php");
    exit;
} else {
    header("Location: index.php");
    exit;
}
