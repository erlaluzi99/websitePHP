<?php
session_start();

require_once 'includes/db_connect.php';

function redirectWithMessage($type, $message) {
    $_SESSION["product_$type"] = $message;
    header("Location: admin_dashboard.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;

    // ADD PRODUCT
    if ($action === 'add') {
        $name = $_POST['name'];
        $price = floatval($_POST['price']);
        $category = $_POST['category'];
        $stock = intval($_POST['stock']);

        $image_path = '';
        if (!empty($_FILES['image']['name'])) {
            $image_name = basename($_FILES['image']['name']);
            $target_file = "productimages/" . time() . "_" . $image_name;

            if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
                $image_path = $target_file;
            } else {
                redirectWithMessage("error", "Image upload failed.");
            }
        }

        $stmt = $conn->prepare("INSERT INTO products (name, price, category, stock, image) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sdsis", $name, $price, $category, $stock, $image_path);
        $stmt->execute() ? redirectWithMessage("success", "Product added.") : redirectWithMessage("error", "Failed to add product.");
    }

    // EDIT PRODUCT
    if ($action === 'edit') {
        $name = $_POST['name'];
        $price = floatval($_POST['price']);
        $category = $_POST['category'];
        $stock = intval($_POST['stock']);

        $image_path = '';
        if (!empty($_FILES['image']['name'])) {
            $image_name = basename($_FILES['image']['name']);
            $target_file = "productimages/" . time() . "_" . $image_name;

            if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
                $image_path = $target_file;
            } else {
                redirectWithMessage("error", "Image upload failed.");
            }
        }

        if ($image_path) {
            $stmt = $conn->prepare("UPDATE products SET name=?, price=?, category=?, stock=?, image=? WHERE id=?");
            $stmt->bind_param("sdsisi", $name, $price, $category, $stock, $image_path, $id);
        } else {
            $stmt = $conn->prepare("UPDATE products SET name=?, price=?, category=?, stock=? WHERE id=?");
            $stmt->bind_param("sdsii", $name, $price, $category, $stock, $id);
        }

        $stmt->execute() ? redirectWithMessage("success", "Product updated.") : redirectWithMessage("error", "Failed to update product.");
    }

    // DELETE PRODUCT
    if ($action === 'delete') {
        if ($id <= 0) redirectWithMessage("error", "Invalid product ID.");

        $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute() ? redirectWithMessage("success", "Product deleted.") : redirectWithMessage("error", "Failed to delete product.");
    }

    redirectWithMessage("error", "Unknown action.");
}
?>
