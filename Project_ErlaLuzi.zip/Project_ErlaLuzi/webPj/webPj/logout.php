<?php
session_start();
require_once 'includes/db_connect.php';

if (isset($_COOKIE['remember_me'])) {
    $token = $_COOKIE['remember_me'];

    $stmt = $conn->prepare("DELETE FROM remember_tokens WHERE token = ?");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $stmt->close();

    setcookie('remember_me', '', time() - 3600, "/");
}

session_unset();
session_destroy();

header("Location: index.php");
exit;
